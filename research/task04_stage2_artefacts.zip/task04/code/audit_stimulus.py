"""
Stimulus-generation audit (Task 04, section 3).

Generates N participant schedules with the Task 03 generator and checks every
property listed in the Task 04 brief. Failures are reported, never patched.

Usage:  python3 audit_stimulus.py [N] [outfile.json]
"""
import json
import sys
from collections import Counter

import numpy as np

import stimulus as st

TOL = 1e-9
ALLOWED_DURATIONS = {9.0, 10.5, 12.0, 13.5, 15.0}


def audit(n_participants=200, seed_mode="restricted", master_seed=20261010):
    rng = np.random.default_rng(master_seed)
    if seed_mode == "restricted":
        # participantSeed < floor(2^32 / 1000) so seed*1000 + index cannot wrap
        seeds = rng.choice(4_294_967, size=n_participants, replace=False).tolist()
    else:
        # full 32-bit participant seeds, as a browser might draw them
        seeds = rng.integers(0, 2**32, size=n_participants).tolist()

    checks = Counter()
    failures = []
    def fail(name, msg):
        checks[name + ":FAIL"] += 1
        if len(failures) < 50:
            failures.append(f"{name}: {msg}")
    def ok(name):
        checks[name + ":pass"] += 1

    all_trial_seeds = []
    first_trial_cells = Counter()
    position_by_type = {}
    m_on_values = []
    det_onsets = []
    max_offset_order = 0.0
    min_onset_order = 1e9
    max_offset_det = 0.0

    for ps in seeds:
        sch = st.generate_schedule(int(ps))
        order = sch["order"]
        det = sch["detection"]

        # 1 Orthogonality of onset and offset asynchronies (order block)
        don = np.array([t.d_on for t in order])
        doff = np.array([t.d_off for t in order])
        cov = np.mean((don - don.mean()) * (doff - doff.mean()))
        (ok if abs(cov) < TOL else lambda n: fail(n, f"seed {ps} cov={cov}"))("orthogonality_cov0")
        if abs(don.mean()) > TOL or abs(doff.mean()) > TOL:
            fail("asynchrony_means_zero", f"seed {ps}")
        else:
            ok("asynchrony_means_zero")

        # 2 Allocation of nine cells
        cells = Counter((t.d_on, t.d_off) for t in order)
        expected = {(a, b): 2 for a in (-3.0, 0.0, 3.0) for b in (-3.0, 0.0, 3.0)}
        expected[(0.0, 0.0)] = 4
        (ok if cells == Counter(expected) else lambda n: fail(n, f"seed {ps} {cells}"))("nine_cell_allocation")
        if len(order) != 20:
            fail("order_trial_count_20", f"seed {ps} n={len(order)}")
        else:
            ok("order_trial_count_20")

        # 3 Balanced left/right leadership (onset and offset separately)
        on_lead = Counter(np.sign(don)); off_lead = Counter(np.sign(doff))
        if on_lead[1.0] == on_lead[-1.0] and off_lead[1.0] == off_lead[-1.0]:
            ok("left_right_leadership_balanced")
        else:
            fail("left_right_leadership_balanced", f"seed {ps} {on_lead} {off_lead}")

        # 4 Balanced lightening/darkening, overall and within each cell
        dirs = Counter(t.direction for t in order)
        within = all(Counter(t.direction for t in order if (t.d_on, t.d_off) == c)[1] ==
                     Counter(t.direction for t in order if (t.d_on, t.d_off) == c)[-1]
                     for c in expected)
        if dirs[1] == dirs[-1] and within:
            ok("direction_balanced_order")
        else:
            fail("direction_balanced_order", f"seed {ps} {dirs}")
        ddirs = Counter(t.direction for t in det if t.change_L or t.change_R)
        (ok if ddirs[1] == ddirs[-1] else lambda n: fail(n, f"seed {ps} {ddirs}"))("direction_balanced_detection_changing")

        # 5 Correct onset and offset timing
        for t in order:
            got_on = t.onset_R - t.onset_L
            got_off = t.offset_R - t.offset_L
            if abs(got_on - t.d_on) > TOL or abs(got_off - t.d_off) > TOL:
                fail("asynchrony_realised_exactly", f"seed {ps} {t.template_id} on={got_on} off={got_off}")
            else:
                ok("asynchrony_realised_exactly")
            lo = min(t.onset_L, t.onset_R); hi = max(t.offset_L, t.offset_R)
            min_onset_order = min(min_onset_order, lo); max_offset_order = max(max_offset_order, hi)
            if lo < 1.5 - TOL or hi > st.T_TRIAL + TOL:
                fail("order_timing_within_trial", f"seed {ps} {t.template_id} {lo} {hi}")
            else:
                ok("order_timing_within_trial")
            if hi > 22.5 + TOL:
                fail("order_offset_within_task03_stated_bound_22.5", f"{hi}")
            m_on_values.append(t.m_on)
        for t in det:
            for ch, on, du in [(t.change_L, t.onset_L, t.dur_L), (t.change_R, t.onset_R, t.dur_R)]:
                if ch:
                    det_onsets.append(on)
                    max_offset_det = max(max_offset_det, on + du)
                    if on + du > st.T_TRIAL + TOL:
                        fail("detection_timing_within_trial", f"seed {ps} {t.template_id} {on+du}")
                    else:
                        ok("detection_timing_within_trial")

        # 6 Valid ramp durations
        for t in order:
            if t.dur_L in ALLOWED_DURATIONS and t.dur_R in ALLOWED_DURATIONS and t.dur_L > 0 and t.dur_R > 0:
                ok("order_durations_valid")
            else:
                fail("order_durations_valid", f"seed {ps} {t.dur_L} {t.dur_R}")

        # 7 Constant final change magnitude (and identical end states within trial)
        for t in order:
            eL = st.lightness(st.T_TRIAL, t.onset_L, t.dur_L, t.direction, True)
            eR = st.lightness(st.T_TRIAL, t.onset_R, t.dur_R, t.direction, True)
            if abs(eL - eR) < TOL and abs(abs(eL - st.L0) - st.M_CHANGE) < TOL:
                ok("final_magnitude_constant_order")
            else:
                fail("final_magnitude_constant_order", f"seed {ps} {eL} {eR}")

        # 8 No unintended timing information in static endpoints
        #   start frame: both discs at L0; end frame: both at L0 + dir*M.
        #   Also: no other static per-trial attribute (direction, m_on) predicts
        #   the onset leader.
        for t in order:
            s0 = (st.lightness(0.0, t.onset_L, t.dur_L, t.direction, True),
                  st.lightness(0.0, t.onset_R, t.dur_R, t.direction, True))
            if abs(s0[0] - st.L0) < TOL and abs(s0[1] - st.L0) < TOL:
                ok("start_frame_identical")
            else:
                fail("start_frame_identical", f"seed {ps}")

        # bookkeeping for randomisation checks
        first_trial_cells[(order[0].d_on, order[0].d_off)] += 1
        for t in order:
            key = (t.d_on, t.d_off)
            position_by_type.setdefault(key, []).append(t.position)
        all_trial_seeds += [t.seed for t in det + order]

        # 9 Reproducibility from recorded seed
        d1 = st.schedule_digest(sch)
        d2 = st.schedule_digest(st.generate_schedule(int(ps)))
        (ok if d1 == d2 else lambda n: fail(n, f"seed {ps}"))("reproducible_from_seed")

    # Seed collisions across participants (Task 03 seed formula)
    seed_counts = Counter(all_trial_seeds)
    collisions = sum(c - 1 for c in seed_counts.values() if c > 1)

    # Leakage check across the whole pool: does direction or m_on predict onset leader?
    pool = [t for ps in seeds[:50] for t in st.generate_schedule(int(ps))["order"] if t.d_on != 0]
    lead = np.array([np.sign(t.d_on) for t in pool])
    corr_dir = float(np.corrcoef(lead, [t.direction for t in pool])[0, 1])
    corr_mon = float(np.corrcoef(lead, [t.m_on for t in pool])[0, 1])
    # Duration/rate leakage: the longer (slower) ramp's side vs onset leader
    dur_contrast = np.array([np.sign(t.dur_L - t.dur_R) for t in pool])
    corr_dur = float(np.corrcoef(lead, dur_contrast)[0, 1])

    mean_pos = {f"{k[0]:+.0f},{k[1]:+.0f}": float(np.mean(v)) for k, v in position_by_type.items()}

    summary = {
        "n_participants": n_participants,
        "seed_mode": seed_mode,
        "checks": dict(sorted(checks.items())),
        "n_failures_listed": len(failures),
        "failures_first_50": failures,
        "trial_seed_collisions": collisions,
        "order_block_min_onset_s": round(min_onset_order, 4),
        "order_block_max_offset_s": round(max_offset_order, 4),
        "detection_block_max_offset_s": round(max_offset_det, 4),
        "m_on_range_observed": [round(min(m_on_values), 4), round(max(m_on_values), 4)],
        "detection_onset_range_observed": [round(min(det_onsets), 4), round(max(det_onsets), 4)],
        "first_trial_cell_counts": {f"{k[0]:+.0f},{k[1]:+.0f}": v for k, v in sorted(first_trial_cells.items())},
        "mean_presentation_position_by_cell(0..19)": mean_pos,
        "leakage_corr_onset_leader_vs_direction": round(corr_dir, 6),
        "leakage_corr_onset_leader_vs_m_on": round(corr_mon, 6),
        "corr_onset_leader_vs_longer_ramp_side(nonzero d_on trials)": round(corr_dur, 6),
    }
    return summary


if __name__ == "__main__":
    n = int(sys.argv[1]) if len(sys.argv) > 1 else 200
    out = sys.argv[2] if len(sys.argv) > 2 else "../results/stimulus_audit.json"
    res = {"restricted_seed_range": audit(n, "restricted"),
           "full_32bit_seed_range": audit(n, "full32")}
    with open(out, "w") as f:
        json.dump(res, f, indent=2)
    print(json.dumps(res, indent=2))
