"""
Mathematical and statistical model checks (Task 04, section 1).
Each check prints and saves its numerical result.

Usage:  python3 model_checks.py [outfile.json]
"""
import json
import sys

import numpy as np
from scipy.special import expit
from scipy.optimize import minimize

import stimulus as st
from ordinal_model import fit, simulate_responses, negloglik, GH_NODES, GH_LOGW
from scipy.special import logsumexp


def design(k=2, m=4):
    tm = st.order_templates(k, m)
    return np.array([t.d_on for t in tm]), np.array([t.d_off for t in tm])


def check_design_identifiability():
    out = {}
    for k in (2, 3, 4):
        don, doff = design(k)
        X = np.column_stack([don, doff])
        XtX = X.T @ X
        out[f"k={k}, J={len(don)}"] = {
            "XtX": XtX.tolist(),
            "corr(d_on,d_off)": float(np.corrcoef(don, doff)[0, 1]),
            "rank": int(np.linalg.matrix_rank(X)),
            "condition_number": float(np.linalg.cond(XtX)),
            "corr(d_on, midpoint)": float(np.corrcoef(don, (don + doff) / 2)[0, 1]),
            "corr(d_on, duration_contrast d_on-d_off)": float(np.corrcoef(don, don - doff)[0, 1]),
        }
    return out


def check_stimulus_algebra():
    """Symbolic identities verified on all nine cells."""
    rows = []
    for don in (-3.0, 0.0, 3.0):
        for doff in (-3.0, 0.0, 3.0):
            durL = st.D0 + (don - doff) / 2; durR = st.D0 - (don - doff) / 2
            for m_on in (3.0, 6.0):
                onL = m_on - don / 2; onR = m_on + don / 2
                offL, offR = onL + durL, onR + durR
                rateL, rateR = st.M_CHANGE / durL, st.M_CHANGE / durR
                rows.append({"d_on": don, "d_off": doff, "m_on": m_on,
                             "durL": durL, "durR": durR,
                             "realised_d_on": onR - onL, "realised_d_off": offR - offL,
                             "midpoint_contrast": ((onR + offR) - (onL + offL)) / 2,
                             "expected_midpoint": (don + doff) / 2,
                             "duration_contrast_L_minus_R": durL - durR,
                             "rate_L": round(rateL, 4), "rate_R": round(rateR, 4),
                             "min_onset": min(onL, onR), "max_offset": max(offL, offR)})
    ok = all(abs(r["realised_d_on"] - r["d_on"]) < 1e-12 and
             abs(r["realised_d_off"] - r["d_off"]) < 1e-12 and
             abs(r["midpoint_contrast"] - r["expected_midpoint"]) < 1e-12 and
             abs(r["duration_contrast_L_minus_R"] - (r["d_on"] - r["d_off"])) < 1e-12
             for r in rows)
    return {"all_identities_hold": ok,
            "min_onset_over_cells_and_m_on_extremes": min(r["min_onset"] for r in rows),
            "max_offset_over_cells_and_m_on_extremes": max(r["max_offset"] for r in rows),
            "rates_L*_per_s": sorted({r["rate_L"] for r in rows}),
            "cells": rows}


def check_sign_convention():
    """Task 03 wrote logit P(r >= k) = theta_k - (w.x) - u with R < S < L.
    Evaluate the implied P(L) for an onset observer with positive w_on."""
    w_on, th = 0.7, 1.0
    out = {}
    for don in (-3.0, 0.0, 3.0):
        eta = w_on * don
        p_L_task03 = float(expit(-th - eta))        # P(r >= L) = logistic(theta_L - eta), theta_L chosen = -1
        p_L_corrected = float(1 - expit(th - eta))  # P(r <= S) = logistic(theta2 - eta)
        out[f"d_on={don:+.0f}"] = {"P(L) Task03 form": round(p_L_task03, 4),
                                   "P(L) corrected form": round(p_L_corrected, 4)}
    # Fit both parameterisations to one large simulated onset dataset
    rng = np.random.default_rng(1)
    don, doff = design(2)
    N = 400
    D_on = np.tile(don, (N, 1)); D_off = np.tile(doff, (N, 1))
    y = simulate_responses(rng, D_on, D_off, 0.7, 0.0, lapse=0.0)
    corr = fit(D_on, D_off, y)

    # Task 03 form: logit P(r >= k) = theta_k - eta - u, categories R<S<L.
    # Equivalent to P(r <= k-1) = 1 - logistic(theta_k - eta - u).
    def nll_task03(p):
        thS, thL = p[0], p[0] - np.exp(p[1])  # P(r>=S) >= P(r>=L) requires thS > thL
        w1, w2, sd = p[2], p[3], np.exp(p[4])
        eta = (w1 * D_on + w2 * D_off)[:, :, None] + sd * GH_NODES[None, None, :]
        geS = expit(thS - eta); geL = expit(thL - eta)
        pr = np.where(y[:, :, None] == 0, 1 - geS, np.where(y[:, :, None] == 1, geS - geL, geL))
        lp = np.log(np.clip(pr, 1e-300, None)).sum(axis=1)
        return -logsumexp(lp + GH_LOGW[None, :], axis=1).sum()
    r = minimize(nll_task03, np.array([1.0, np.log(2.0), 0.0, 0.0, np.log(0.5)]), method="BFGS")
    w1, w2 = r.x[2], r.x[3]
    oi = w1 / (abs(w1) + abs(w2))
    out["fit_true_onset_observer_w=(0.7,0)"] = {
        "corrected_model": {"w_on": round(corr["w_on"], 4), "w_off": round(corr["w_off"], 4),
                            "theta1<theta2": corr["theta1"] < corr["theta2"], "nll": round(corr["nll"], 4)},
        "task03_form_as_written": {"w_on": round(float(w1), 4), "w_off": round(float(w2), 4),
                                   "OI_task03": round(float(oi), 4), "nll": round(float(r.fun), 4),
                                   "note": "Same likelihood, weights negated; OI = -1 would read as anti-onset."}}
    return out


def check_onset_index():
    def OI(a, b):
        d = abs(a) + abs(b)
        return None if d == 0 else a / d
    cases = {"pure onset (1,0)": (1, 0), "midpoint (0.5,0.5)": (0.5, 0.5),
             "pure offset (0,1)": (0, 1), "duration heuristic (1,-1)": (1, -1),
             "anti-onset (-1,0)": (-1, 0), "near zero (0.01,-0.01)": (0.01, -0.01),
             "near zero (0.01,0.01)": (0.01, 0.01), "zero (0,0)": (0, 0),
             "threshold-onset q=0.2 (0.8,0.2)": (0.8, 0.2)}
    out = {}
    for k, (a, b) in cases.items():
        out[k] = {"OI_task03": OI(a, b),
                  "angle_deg_atan2(w_off,w_on)": round(float(np.degrees(np.arctan2(b, a))), 2) if (a or b) else None,
                  "norm": round(float(np.hypot(a, b)), 4)}
    return out


def check_threshold_crossing_observer():
    """Observer reports which disc first deviates by delta L* from start.
    Deduction: crossing contrast = (1-q) d_on + q d_off with q = delta / M."""
    out = {}
    for delta in (0.5, 2.0, 5.0):
        q = delta / st.M_CHANGE
        worst = 0.0
        for don in (-3.0, 0.0, 3.0):
            for doff in (-3.0, 0.0, 3.0):
                durL = st.D0 + (don - doff) / 2; durR = st.D0 - (don - doff) / 2
                onL, onR = 4.5 - don / 2, 4.5 + don / 2
                cL = onL + q * durL; cR = onR + q * durR
                pred = (1 - q) * don + q * doff
                worst = max(worst, abs((cR - cL) - pred))
        out[f"delta={delta} L* (q={q})"] = {"implied_weights": [1 - q, q],
                                            "max_abs_deviation_from_linear_rule": worst}
    return out


def check_bias_guess_lapse_signatures():
    """Expected response probabilities per cell for observers that a naive
    accuracy summary could confuse."""
    don, doff = design(2)
    cells = sorted(set(zip(don, doff)))
    def probs(w_on, w_off, beta=0.0, tau=1.0, lam=0.0):
        rows = {}
        for (a, b) in cells:
            eta = w_on * a + w_off * b + beta
            pR = expit(-tau - eta); pLe = expit(tau - eta)
            p = np.array([pR, pLe - pR, 1 - pLe])
            p = (1 - lam) * p + lam / 3
            rows[f"({a:+.0f},{b:+.0f})"] = [round(float(x), 3) for x in p]
        return rows
    return {"order_of_probabilities": "[P(R), P(S), P(L)]",
            "onset_a=0.7": probs(0.7, 0.0),
            "guessing_w=0": probs(0.0, 0.0),
            "left_biased_guessing_w=0_beta=1": probs(0.0, 0.0, beta=1.0),
            "onset_a=0.7_lapse=0.15": probs(0.7, 0.0, lam=0.15),
            "onset_a=0.35_no_lapse (half sensitivity)": probs(0.35, 0.0),
            "duration_heuristic_(0.35,-0.35)": probs(0.35, -0.35),
            "midpoint_(0.35,0.35)": probs(0.35, 0.35)}


def check_task03_diagnostic_proportions():
    """Task 03 diagnostic: 'onset-consistent choice on conflict trials'.
    Expected value for each observer type at a = 0.7."""
    out = {}
    for name, (a, b) in {"onset": (0.7, 0.0), "midpoint": (0.35, 0.35), "offset": (0.0, 0.7),
                         "duration heuristic": (0.35, -0.35), "threshold-onset q=0.2": (0.56, 0.14)}.items():
        # conflict cell (+3,-3): onset leader is Left
        eta = a * 3 + b * (-3)
        pL = 1 - expit(1 - eta); pR = expit(-1 - eta)
        # onset-only (+3,0): correct leader L
        eta2 = a * 3
        pL2 = 1 - expit(1 - eta2)
        # offset-only (0,+3): onset observer should say S
        eta3 = b * 3
        pS3 = expit(1 - eta3) - expit(-1 - eta3)
        out[name] = {"conflict(+3,-3): P(onset-consistent L)": round(float(pL), 3),
                     "conflict: P(offset-consistent R)": round(float(pR), 3),
                     "onset-only(+3,0): P(correct L)": round(float(pL2), 3),
                     "offset-only(0,+3): P(S)": round(float(pS3), 3)}
    return out


if __name__ == "__main__":
    out = sys.argv[1] if len(sys.argv) > 1 else "../results/model_checks.json"
    res = {"design_identifiability": check_design_identifiability(),
           "stimulus_algebra": check_stimulus_algebra(),
           "sign_convention": check_sign_convention(),
           "onset_index": check_onset_index(),
           "threshold_crossing_observer": check_threshold_crossing_observer(),
           "bias_guess_lapse_signatures": check_bias_guess_lapse_signatures(),
           "task03_diagnostic_proportions": check_task03_diagnostic_proportions()}
    with open(out, "w") as f:
        json.dump(res, f, indent=1, default=float)
    view = dict(res); view["stimulus_algebra"] = {k: v for k, v in res["stimulus_algebra"].items() if k != "cells"}
    print(json.dumps(view, indent=1, default=float))
