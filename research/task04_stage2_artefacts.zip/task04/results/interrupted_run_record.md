# Record: interrupted full recovery run (v1 architecture)

- Command: `python3 simulate_recovery.py --reps 1000 --workers 2 --out ../results/recovery`
- Planned workload: 48,000 fits (3 allocations x [13 scenarios + 3 lapse-model refits] x 1,000 repetitions)
- Started: 2026-10-10 ~00:29 AEDT
- Stopped: 2026-10-10 01:03:47 AEDT, SIGTERM to the parent process on the user's instruction. The two pool workers (PIDs 451, 452) exited on their own within ~3 s; a follow-up SIGTERM to them found no such processes.
- Elapsed: ~35 minutes on 2 worker processes (each ~32 min CPU at 98%)
- Outcome: NO recoverable parameter-recovery results. The v1 script collected all
  results in memory via multiprocessing.Pool.map and wrote output only at completion.
  No `recovery_fits.csv` or `recovery_summary.json` was produced. `recovery_run.log` is empty.
- Number of fits completed before termination: unknown (not observable in the v1 architecture).
- Cause: architecture defect (no incremental writes, no progress logging), not a model or data error.
- Preserved: v1 script unchanged at `code/simulate_recovery.py`; its empty log `results/recovery_run.log`;
  two 8-repetition pipeline smoke tests in `results/smoke/` (smoke1 used the v1 fitting rule,
  smoke2 the v2 fitting rule after deviation D1). Smoke-test outputs are pipeline checks only and
  are not parameter-recovery evidence.
- Successor: `code/simulate_recovery_v2.py` (checkpointed, resumable), run in stages.
