"""
Rendering and quantisation audit (Task 04, section 4).

Computational only. Nothing here measures what a physical display emits or
what an observer sees. sRGB is assumed to be the display transfer function.

Compares four temporal rendering methods for a disc whose CIELAB lightness
follows the Task 03 ramp:
  none      : round to nearest 8-bit code each frame (no dithering)
  uniform   : Task 03 Part 6.4 as written (add U[-0.5, 0.5) code, then round)
  tpdf      : triangular-PDF dither (sum of two U[-0.5,0.5)), then round
  errdiff   : first-order temporal error diffusion (sigma-delta), then round

Usage:  python3 render_audit.py [outfile.json]
"""
import json
import sys

import numpy as np

L0, M = 55.0, 10.0
RAMPS_A = [9.0, 10.5, 12.0, 13.5, 15.0]
COMPRESSION_B = 8.0
REFRESH = [30, 60, 75, 120, 144]
PRE, POST = 2.0, 2.0      # seconds of static display before onset / after offset
LOWPASS_HZ = 10.0         # band treated as "low-frequency" for error power
RNG_SEED = 777


def lstar_to_Y(L):
    L = np.asarray(L, dtype=float)
    return np.where(L > 8.0, ((L + 16.0) / 116.0) ** 3, L / 903.3)


def Y_to_code(Y):
    Y = np.asarray(Y, dtype=float)
    v = np.where(Y <= 0.0031308, 12.92 * Y, 1.055 * np.power(Y, 1 / 2.4) - 0.055)
    return 255.0 * v


def code_to_Y(c):
    v = np.asarray(c, dtype=float) / 255.0
    return np.where(v <= 0.04045, v / 12.92, ((v + 0.055) / 1.055) ** 2.4)


def ideal_codes(dur, direction, fps, compression=1.0):
    """Ideal (unquantised) code value at each frame, onset at PRE seconds."""
    d = dur / compression
    n = int(round((PRE + d + POST) * fps))
    t = np.arange(n) / fps
    p = np.clip((t - PRE) / d, 0.0, 1.0)
    L = L0 + direction * M * p
    return t, Y_to_code(lstar_to_Y(L)), (t >= PRE) & (t <= PRE + d)


def render(ideal, method, rng):
    if method == "none":
        return np.round(ideal)
    if method == "uniform":
        return np.round(ideal + rng.uniform(-0.5, 0.5, ideal.shape))
    if method == "tpdf":
        return np.round(ideal + rng.uniform(-0.5, 0.5, ideal.shape)
                        + rng.uniform(-0.5, 0.5, ideal.shape))
    if method == "errdiff":
        out = np.empty_like(ideal); e = 0.0
        for i, v in enumerate(ideal):
            q = np.round(v + e); out[i] = q; e = v + e - q
        return out
    raise ValueError(method)


def lowfreq_rms(err, fps, cutoff=LOWPASS_HZ):
    """RMS of the error component below `cutoff` Hz (FFT brick-wall)."""
    E = np.fft.rfft(err - err.mean())
    f = np.fft.rfftfreq(len(err), 1 / fps)
    E[f > cutoff] = 0
    return float(np.sqrt(np.mean(np.fft.irfft(E, n=len(err)) ** 2)))


def onset_marker_ratio(disp, t, onset, fps, win=1.0):
    """Variance of frame-to-frame change in the 1 s after onset divided by the
    1 s before. 1.0 means the noise statistics do not mark the onset."""
    d = np.diff(disp)
    tt = t[1:]
    pre = d[(tt >= onset - win) & (tt < onset)]
    post = d[(tt >= onset) & (tt < onset + win)]
    vp, vq = pre.var(), post.var()
    if vp == 0 and vq == 0:
        return 1.0
    if vp == 0:
        return float("inf")
    return float(vq / vp)


def static_noise(method, code_value, fps, seconds, rng):
    ideal = np.full(int(seconds * fps), code_value)
    disp = render(ideal, method, rng)
    return float(np.std(disp)), float(np.mean(np.abs(np.diff(disp)) > 0))


def main(out):
    rng = np.random.default_rng(RNG_SEED)
    res = {"assumptions": {
        "transfer_function": "IEC 61966-2-1 sRGB, 8-bit, no display colour management",
        "L0": L0, "M": M, "lowfreq_cutoff_Hz": LOWPASS_HZ,
        "note": "computational only; no physical display or observer measured"}}

    # --- 1. Static code values and step sizes ----------------------------------
    rows = {}
    for L in [45.0, 55.0, 65.0]:
        c = float(Y_to_code(lstar_to_Y(L)))
        Y = float(lstar_to_Y(L))
        cf = np.floor(c)
        dY = float(code_to_Y(cf + 1) - code_to_Y(cf))
        Lp = float(116 * code_to_Y(cf + 1) ** (1 / 3) - 16 - (116 * code_to_Y(cf) ** (1 / 3) - 16))
        rows[f"L*={L:.0f}"] = {"ideal_code": round(c, 4), "fractional_part": round(c - cf, 4),
                               "one_code_step_dY_over_Y_percent": round(100 * dY / Y, 3),
                               "one_code_step_in_L*": round(Lp, 4)}
    res["code_values"] = rows
    c55, c65, c45 = (Y_to_code(lstar_to_Y(x)) for x in (55, 65, 45))
    res["codes_spanned"] = {"lightening_55_to_65": round(float(c65 - c55), 3),
                            "darkening_55_to_45": round(float(c55 - c45), 3)}

    # --- 2. Per-ramp analysis --------------------------------------------------
    ramp_rows = []
    for cond, comp in [("A", 1.0), ("B", COMPRESSION_B)]:
        for dur in RAMPS_A:
            for direction in (+1, -1):
                for fps in REFRESH:
                    t, ideal, ramping = ideal_codes(dur, direction, fps, comp)
                    onset = PRE
                    for method in ["none", "uniform", "tpdf", "errdiff"]:
                        reps = 1 if method in ("none", "errdiff") else 20
                        acc = {"max_abs_err": [], "lf_rms": [], "max_step": [], "p_step2plus": [],
                               "onset_ratio": [], "mean_err": []}
                        for _ in range(reps):
                            disp = render(ideal, method, rng)
                            err = disp - ideal
                            acc["max_abs_err"].append(np.max(np.abs(err)))
                            acc["mean_err"].append(np.mean(err[ramping]))
                            acc["lf_rms"].append(lowfreq_rms(err, fps))
                            st = np.abs(np.diff(disp))
                            acc["max_step"].append(st.max())
                            acc["p_step2plus"].append(np.mean(st >= 2))
                            acc["onset_ratio"].append(onset_marker_ratio(disp, t, onset, fps))
                        row = {"condition": cond, "ramp_s_real": dur, "ramp_s_displayed": dur / comp,
                               "direction": direction, "fps": fps, "method": method, "reps": reps,
                               "max_abs_err_codes": round(float(np.max(acc["max_abs_err"])), 4),
                               "mean_err_during_ramp_codes": round(float(np.mean(acc["mean_err"])), 4),
                               "lowfreq_rms_err_codes": round(float(np.mean(acc["lf_rms"])), 4),
                               "max_frame_step_codes": int(np.max(acc["max_step"])),
                               "p_frame_step_ge2": round(float(np.mean(acc["p_step2plus"])), 6),
                               "onset_marker_ratio_median": (round(float(np.median(acc["onset_ratio"])), 3)
                                                             if np.all(np.isfinite(acc["onset_ratio"]))
                                                             else "inf")}
                        if method == "none":
                            disp = np.round(ideal)
                            changes = np.where(np.diff(disp) != 0)[0]
                            ts = t[1:][changes]
                            row["n_code_steps"] = int(len(changes))
                            row["mean_interval_between_steps_s"] = (round(float(np.mean(np.diff(ts))), 4)
                                                                     if len(ts) > 1 else None)
                            row["first_step_latency_after_onset_s"] = (round(float(ts[0] - onset), 4)
                                                                       if len(ts) else None)
                        ramp_rows.append(row)
    res["ramps"] = ramp_rows

    # --- 3. Static (non-changing) discs: does dithering add flicker? -----------
    stat = {}
    for method in ["none", "uniform", "tpdf", "errdiff"]:
        for label, code in [("L*=55", float(c55)), ("L*=65", float(c65)), ("L*=45", float(c45))]:
            sd, pchg = static_noise(method, code, 60, 10, rng)
            stat[f"{method}|{label}"] = {"sd_codes": round(sd, 4),
                                          "p_frames_changing": round(pchg, 4)}
    res["static_disc_noise_60Hz"] = stat

    # --- 4. Dropped frames: ideal change across a gap (codes) -------------------
    drops = {}
    for cond, comp in [("A", 1.0), ("B", COMPRESSION_B)]:
        for fps in [60, 30]:
            fastest = (float(c65 - c55) / (9.0 / comp))  # codes per second, fastest ramp
            drops[f"{cond}@{fps}Hz"] = {
                "ideal_change_per_frame_codes": round(fastest / fps, 4),
                "ideal_change_across_1_dropped_frame_codes": round(2 * fastest / fps, 4),
                "ideal_change_across_3_dropped_frames_codes": round(4 * fastest / fps, 4)}
    res["dropped_frames_fastest_ramp"] = drops

    # --- 5. Condition C geometry (static plot) ----------------------------------
    px_per_s, px_per_L = 25.0, 120.0 / (2 * M + 4)
    geom = {}
    for dur in RAMPS_A:
        run, rise = dur * px_per_s, M * px_per_L
        geom[f"ramp_{dur}s"] = {"run_px": run, "rise_px": round(rise, 2),
                                "angle_deg": round(float(np.degrees(np.arctan2(rise, run))), 2)}
    geom["asynchrony_3s_px"] = 3 * px_per_s
    geom["panel_px_per_L*"] = round(px_per_L, 3)
    res["condition_C_geometry"] = geom

    # --- 6. Noise modulation at onset, precise estimate (200 reps, 60 Hz) ------
    nm = {}
    for cond, comp in [("A", 1.0), ("B", COMPRESSION_B)]:
        for method in ["uniform", "tpdf", "errdiff"]:
            ratios = []
            for dur in RAMPS_A:
                for direction in (+1, -1):
                    t, ideal, _ = ideal_codes(dur, direction, 60, comp)
                    reps = 200 if method != "errdiff" else 1
                    for _ in range(reps):
                        ratios.append(onset_marker_ratio(render(ideal, method, rng), t, PRE, 60))
            ratios = np.array(ratios)
            nm[f"{cond}|{method}"] = {"n": int(len(ratios)),
                                      "mean_ratio": round(float(ratios.mean()), 4),
                                      "p2.5": round(float(np.percentile(ratios, 2.5)), 4),
                                      "p97.5": round(float(np.percentile(ratios, 97.5)), 4)}
    res["onset_noise_modulation_60Hz_precise"] = nm

    with open(out, "w") as f:
        json.dump(res, f, indent=1)
    return res


if __name__ == "__main__":
    out = sys.argv[1] if len(sys.argv) > 1 else "../results/render_audit.json"
    r = main(out)
    print(json.dumps({k: r[k] for k in ["code_values", "codes_spanned",
                                          "static_disc_noise_60Hz",
                                          "dropped_frames_fastest_ramp",
                                          "condition_C_geometry"]}, indent=1))
