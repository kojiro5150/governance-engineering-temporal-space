# Task 04 — Stage 2 parameter-recovery report (preliminary)

- Date: 2026-10-10
- Status: **Preliminary.** 100 repetitions per scenario at one allocation. Not a gate decision.
- Run directory: `results/stage2/J20_reps100/` (manifest, 40 batch files, progress log, `fits.csv`, `summary.json`)
- Code: `code/simulate_recovery_v2.py` (runner), `code/simulate_recovery.py` (v1 scenario definitions, seeds and criteria, unchanged), `code/ordinal_model.py` (fitting model, including deviation D1)

## 1. What happened before Stage 2

- The v1 full run (48,000 planned fits) was stopped at 01:03:47 after ~35 minutes. **It produced no recoverable parameter-recovery results** (see `results/interrupted_run_record.md`).
- Smoke tests (8 repetitions) are pipeline checks only and are not used below.

## 2. Infrastructure validation (executed)

| Check | Result | Evidence |
|---|---|---|
| 1 worker vs 2 workers, same seeds | Byte-identical fit results | `results/v2_validation/final_code/reproducibility_check.json` (21 jobs, SHA-256 `4e5964c8…`) |
| Split and reordered execution vs single pass | Byte-identical | same file |
| SIGKILL mid-run, then two resumes | Byte-identical to an uninterrupted run (96 fits) | `results/v2_validation/kill_resume_check.json` |
| Re-running a completed run | No new fits; no duplicates | status output, test 3 |
| Resume with changed config | Refused (exit 1) | test 4 |
| Injected duplicate batch | Aggregation refused (exit 1) | test 5 |
| Leftover partial files after kill | None (atomic `os.replace`) | test 6 |

One defect found and fixed during validation: a closed stdout pipe stopped a run. Progress printing now ignores `BrokenPipeError`; `progress.jsonl` is the authoritative log. The fix did not change fit results (same SHA-256 before and after).

## 3. Why 48,000 fits were planned, and whether that is necessary

- **Origin:** 3 allocations (J = 20, 28, 36) × (13 observer scenarios + 3 lapse-model refits) × 1,000 repetitions. 1,000 repetitions put the Monte Carlo standard error of a 95% coverage estimate at about 0.007, so coverage could be judged against the [0.90, 0.98] band in a single pass for every allocation.
- **Assessment:** over-provisioned for a pre-build decision.
  - The larger allocations are needed only if J = 20 fails. They were run unconditionally.
  - 1,000 repetitions are needed only for criteria whose estimates sit near a pass/fail boundary. Bias, stability and onset-versus-midpoint discrimination are decided clearly at 100 repetitions (Section 5).
  - More simulated fits increase precision about the estimator's behaviour. They add no information to the proposed experiment. If the 20-trial design cannot discriminate strategies, the remedy is a design change, not more simulation.

## 4. Stage 2 configuration and runtime

- 13 scenarios × 100 repetitions at J = 20 (2 trials per non-zero cell, 4 simultaneous), N = 12 participants per simulated condition, plus lapse-model refits of the same datasets for S01, S10 and S12. **1,600 fits.**
- Generation: logistic decision noise, ternary thresholds ±1, participant bias SD 0.5, baseline lapse 0.02 (scenario overrides as listed).
- Pre-run estimate: ~3 minutes (range 2.5–6). **Measured: 160.5 s wall time on 2 workers** (10.0 fits/s overall; median 0.171 s per fit per worker). Errors: 0. Missing: 0. Unstable: 32 of 1,600, of which 26 were lapse-model fits.

## 5. Preliminary findings (standard model unless stated)

Monte Carlo standard errors at 100 repetitions: about 0.022 for a coverage near 0.95; about 0.007 to 0.011 for mean bias in weight units.

| Scenario | True (w_on, w_off) | Bias w_on / a | Bias w_off / a | Median SE w_on | Coverage w_on | Coverage w_off | Unstable |
|---|---|---|---|---|---|---|---|
| S01 onset, moderate | (0.70, 0) | −0.018 | −0.011 | 0.073 | 0.93 | 0.95 | 0.00 |
| S02 onset, low | (0.33, 0) | −0.023 | +0.002 | 0.057 | 0.97 | 0.94 | 0.00 |
| S03 onset, high | (1.07, 0) | −0.028 | −0.005 | 0.102 | **0.899** | 0.97 | 0.01 |
| S04 midpoint, moderate | (0.35, 0.35) | −0.010 | −0.001 | 0.059 | 0.97 | 0.93 | 0.00 |
| S05 midpoint, low | (0.17, 0.17) | +0.028 | −0.012 | 0.054 | 0.96 | 0.94 | 0.00 |
| S06 midpoint, high | (0.535, 0.535) | −0.020 | −0.009 | 0.069 | 0.92 | 0.92 | 0.01 |
| S07 threshold-onset, q = 0.2 | (0.56, 0.14) | −0.022 | −0.014 | 0.065 | 0.96 | 0.94 | 0.00 |
| S08 offset, moderate | (0, 0.70) | +0.006 | +0.000 | 0.060 | 0.97 | 0.96 | 0.00 |
| S09 duration heuristic | (0.35, −0.35) | −0.006 | −0.003 | 0.059 | 0.96 | 0.97 | 0.00 |
| S10 guessing | (0, 0) | n/a | n/a | 0.052 | 0.99 | 0.96 | 0.00 |
| S11 biased onset | (0.70, 0) | −0.043 | −0.010 | 0.077 | 0.94 | 0.97 | 0.00 |
| S12 lapse 0.15, standard model | (0.70, 0) | **−0.218** | −0.013 | 0.066 | **0.36** | 0.92 | 0.01 |
| S12 lapse 0.15, lapse model | (0.70, 0) | +0.097 | −0.029 | 0.209 | 0.88 | 0.97 | 0.04 |
| S13 heterogeneous weights, thresholds | (0.70, 0) | −0.045 | −0.003 | 0.072 | **0.83** | 0.94 | 0.00 |

### Strategy discrimination (angle φ = atan2(w_off, w_on); 95% interval from the estimated covariance)

| Truth | P(interval excludes 0°) | P(interval excludes 45°) | P(interval excludes −45°) | Median interval width |
|---|---|---|---|---|
| Onset, moderate (0°) | 0.06 | **1.00** | 1.00 | 19.5° |
| Onset, low (0°) | 0.06 | 0.98 | 0.99 | 37.3° |
| Midpoint, moderate (45°) | **1.00** | 0.08 | 1.00 | 24.7° |
| Midpoint, low (45°) | 0.84 | 0.07 | 0.99 | 49.6° |
| Threshold-onset q = 0.2 (14°) | **0.64** | 1.00 | 1.00 | 22.6° |
| Duration heuristic (−45°) | 1.00 | 1.00 | 0.02 | 24.2° |
| Guessing (undefined) | 0.31 | 0.25 | 0.37 | 267° |

Task 03's onset index (OI), shown for comparison: duration heuristic 0.495 and midpoint 0.497 (indistinguishable, as the algebra predicted); guessing 5th to 95th percentile −0.87 to 0.89 (uninformative without a sensitivity gate).

### Pre-specified criteria at J = 20 (preliminary, 100 repetitions)

| Criterion | Result | Note |
|---|---|---|
| RC1 bias ≤ 0.10 a (core) | Pass | Largest core bias 0.043 a (S11) |
| RC2 coverage in [0.90, 0.98] (core) | **Fail, narrowly** | S03 coverage 0.899 against a 0.90 floor, Monte Carlo SE ≈ 0.03 at this coverage. Not distinguishable from passing at 100 repetitions. All other core scenarios 0.92–0.97 |
| RC3 unstable ≤ 0.05 (all) | Pass | Maximum 0.01 (standard model) |
| RC4 onset vs midpoint ≥ 0.80 | Pass | 1.00 and 1.00 |
| RC5 null false interpretation ≤ 0.07 | Pass | 0.01 |

## 6. Interpretation (preliminary)

1. **The specified 20-trial design separates onset-driven from midpoint-driven observers clearly** at moderate sensitivity, and still at low sensitivity for onset truth (0.98). This was the critical question; on this evidence it does not need more trials.
2. **It does not separate a pure onset observer from a threshold-onset observer with q = 0.2** (0.64). Small offset weights are therefore uninformative about strategy, consistent with the deduction that detection latency creates offset weight.
3. **Intervals run slightly narrow when sensitivity is high** (S03 0.899, S06 0.92; S03 empirical SD 0.110 against median SE 0.102). This needs confirmation at more repetitions before it counts as a failure.
4. **Two robustness problems matter more than the coverage margin:**
   - *Lapses.* A 15% lapse rate attenuates w_on by 22% under the standard model (coverage 0.36). The lapse model reduces bias to about 10%, but doubles the SE, is unstable in 21% of guessing-observer fits, and its estimated lapse rate sits at the lower boundary in 45% (S01), 57% (S10) and 23% (S12) of fits, including 23% of fits where the true lapse rate is 0.15. With 20 trials per person, lapses and low sensitivity are confounded. If condition A has more vigilance lapses, A would appear less sensitive for reasons unrelated to recognising onset order.
   - *Between-participant heterogeneity in weights and thresholds* (not modelled) drops w_on coverage to 0.83. The intervals are too narrow when participants differ in sensitivity, which is the realistic case.

## 7. Minimum additional simulation for a defensible BUILD / REVISE / STOP

Not started. Each item is conditional and small.

| Item | Purpose | Size | Est. runtime |
|---|---|---|---|
| A. Extend core scenarios (S01, S03, S04, S06, S07, S08, S09, S11) at J = 20 from 100 to 500 repetitions, reusing the same seeds | Resolve RC2 near the 0.90 floor (Monte Carlo SE ≈ 0.01) | 3,200 fits | ~5–6 min |
| B. Pre-specify and test one interval method robust to heterogeneity (participant-cluster bootstrap or participant-level random slopes) on S03 and S13 | Decide whether intervals can be made valid, or whether the analysis plan must change | ~200–400 fits plus bootstrap cost | to be estimated from a 10-repetition timing run |
| C. Test a design response to lapses: add a few easy catch trials (large, unambiguous asynchrony) that estimate lapse rate independently of sensitivity | Decide whether the lapse confound can be controlled within the 30-minute limit | S12 and S10, 100–200 repetitions | ~1–2 min plus specification work |

Not needed for the pre-build decision: J = 28 and J = 36 allocations (J = 20 already discriminates strategies), and 1,000 repetitions for scenarios with clear results.

A and C are needed before Gate 2 can be decided. B is needed if A confirms undercoverage, and should be planned anyway because realistic heterogeneity already breaks the current intervals.
