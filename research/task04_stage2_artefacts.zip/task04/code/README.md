# Task 04 reproducible artefacts

Non-participant-facing code supporting `research/working/task04-prebuild-validation.md`.
Nothing here is a participant-facing application.

## Requirements

- Python 3.10 or later (run here on Python 3.11)
- numpy (run here on 2.5.3), scipy (run here on 1.18.1)
- Optional: Node.js, only to re-check the PRNG port against JavaScript

## Files

| File | Purpose |
|---|---|
| `stimulus.py` | Deterministic stimulus generator implementing the Task 03 specification (Parts 6–7), with a bit-exact Python port of the JavaScript `mulberry32` PRNG |
| `audit_stimulus.py` | Stimulus-generation audit over N participant schedules (Task 04 §3) |
| `render_audit.py` | Computational rendering and quantisation audit (Task 04 §4) |
| `ordinal_model.py` | Corrected ternary cumulative-logit model with random intercepts; observer simulator |
| `model_checks.py` | Mathematical checks: sign convention, identifiability, onset index, threshold-crossing deduction (Task 04 §1) |
| `simulate_recovery.py` | Repeated parameter-recovery simulation with pre-specified criteria (Task 04 §2) |
| `burden.py` | Session-duration model under stated assumptions (Task 04 §5) |

## Run

From this directory:

```
mkdir -p ../results
python3 audit_stimulus.py 200 ../results/stimulus_audit.json      # < 1 s
python3 render_audit.py ../results/render_audit.json              # ~ 10 s
python3 model_checks.py ../results/model_checks.json              # ~ 3 s
python3 burden.py ../results/burden.json                          # ~ 5 s
python3 simulate_recovery.py --reps 1000 --workers 2 --out ../results/recovery   # ~ 1.5–2 h on 2 cores
```

Quick pipeline check of the simulation (results not meaningful): `--reps 8`.

## Reproducibility

- Every simulated dataset uses a seed derived from SHA-256 of
  `task04-recovery-v1|<scenario>|<allocation>|<rep>`, so any single fit can be
  regenerated without rerunning the batch.
- `recovery_fits.csv` contains one row per fit for independent re-analysis.
- Recovery criteria are defined in `simulate_recovery.py` (`CRITERIA`) and were
  fixed before the main run. One fitting change (parameter bounds and boundary
  handling for the Hessian, `ordinal_model.py`) was made after an 8-repetition
  pipeline smoke test and before the main run; it is documented as deviation D1.
- PRNG port check against JavaScript:

```
node -e 'function m(a){return function(){a|=0;a=a+0x6D2B79F5|0;var t=Math.imul(a^a>>>15,1|a);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296;}} const r=m(12345); console.log(r(),r(),r())'
python3 -c 'from stimulus import Mulberry32; r=Mulberry32(12345); print(r.next(), r.next(), r.next())'
```

## What these artefacts do not show

- Nothing about what physical displays emit or what observers see.
- Nothing about human performance; all observers are simulated.
- Parameter recovery under the generative assumptions coded here only.
